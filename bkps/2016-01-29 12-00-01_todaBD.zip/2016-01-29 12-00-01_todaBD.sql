/*
SQLyog Job Agent v11.11 (64 bit) Copyright(c) Webyog Inc. All Rights Reserved.


MySQL - 5.5.42-37.1 : Database - oximeise_siom
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`oximeise_siom` /*!40100 DEFAULT CHARACTER SET utf8 COLLATE utf8_spanish2_ci */;

USE `oximeise_siom`;

/*Table structure for table `cargosempleados` */

DROP TABLE IF EXISTS `cargosempleados`;

CREATE TABLE `cargosempleados` (
  `cargoEmpleadoId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cargoEmpleadoCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `cargoEmpleadoTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `cargoEmpleadoDesc` text COLLATE utf8_spanish2_ci,
  `cargoEmpleadoEstado` varchar(50) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`cargoEmpleadoId`),
  UNIQUE KEY `UQ_CargosEmpleados_cargoEmpleadoId` (`cargoEmpleadoId`),
  UNIQUE KEY `UQ_CargosEmpleados_cargoEmpleadoCodigo` (`cargoEmpleadoCodigo`),
  UNIQUE KEY `UQ_CargosEmpleados_cargoEmpleadoTitulo` (`cargoEmpleadoTitulo`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `cargosempleados` */

/*!40000 ALTER TABLE `cargosempleados` DISABLE KEYS */;

insert  into `cargosempleados`(`cargoEmpleadoId`,`cargoEmpleadoCodigo`,`cargoEmpleadoTitulo`,`cargoEmpleadoDesc`,`cargoEmpleadoEstado`) values (1,'SUPERUSUAR','Soporte PURO INGENIO SAMARIO','Para el SUPER usuario que tiene acceso a todo.','ACTIVO');
insert  into `cargosempleados`(`cargoEmpleadoId`,`cargoEmpleadoCodigo`,`cargoEmpleadoTitulo`,`cargoEmpleadoDesc`,`cargoEmpleadoEstado`) values (2,'ADMINISTRA','Administrador','Cargos Administrativos con permisos para Administrar tambien el sistema.','ACTIVO');
insert  into `cargosempleados`(`cargoEmpleadoId`,`cargoEmpleadoCodigo`,`cargoEmpleadoTitulo`,`cargoEmpleadoDesc`,`cargoEmpleadoEstado`) values (3,'DESPACHO','conductor','encargados de entrega y recepcion de equipos.','ACTIVO');
insert  into `cargosempleados`(`cargoEmpleadoId`,`cargoEmpleadoCodigo`,`cargoEmpleadoTitulo`,`cargoEmpleadoDesc`,`cargoEmpleadoEstado`) values (5,'CONTABILID','AUXILIAR CONTABLE','ENCARGADA DE FACTURACIÓN CON BASE EN LOS REPORTES DE LOS MOVIMIENTOS DE LOS EQUIPOS','ACTIVO');
insert  into `cargosempleados`(`cargoEmpleadoId`,`cargoEmpleadoCodigo`,`cargoEmpleadoTitulo`,`cargoEmpleadoDesc`,`cargoEmpleadoEstado`) values (6,'SUBGERENCI','SUBGERENTE','','ACTIVO');
insert  into `cargosempleados`(`cargoEmpleadoId`,`cargoEmpleadoCodigo`,`cargoEmpleadoTitulo`,`cargoEmpleadoDesc`,`cargoEmpleadoEstado`) values (7,'RECEPCION','ASISTENTE ADMINISTRATIVO','RECEPECION Y ENVIO DE PEDIDOS. ALQUILER Y VENTA DE EQUIPOS Y OTROS PRODCUTOS.','ACTIVO');
insert  into `cargosempleados`(`cargoEmpleadoId`,`cargoEmpleadoCodigo`,`cargoEmpleadoTitulo`,`cargoEmpleadoDesc`,`cargoEmpleadoEstado`) values (9,'GERENCIA','GERENTE','','ACTIVO');
insert  into `cargosempleados`(`cargoEmpleadoId`,`cargoEmpleadoCodigo`,`cargoEmpleadoTitulo`,`cargoEmpleadoDesc`,`cargoEmpleadoEstado`) values (10,'CONTADOR','CONTADOR','INVENTARIO','ACTIVO');

/*!40000 ALTER TABLE  `cargosempleados` ENABLE KEYS */;

/*Table structure for table `clientes` */

DROP TABLE IF EXISTS `clientes`;

CREATE TABLE `clientes` (
  `clienteId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `clientePersona` bigint(20) NOT NULL,
  `clienteCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `clienteTipo` int(10) DEFAULT NULL,
  `clienteCreado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `clienteModificado` timestamp NULL DEFAULT NULL,
  `clienteBorrado` timestamp NULL DEFAULT NULL,
  `clienteCreo` bigint(20) DEFAULT NULL,
  `clienteModifico` bigint(20) DEFAULT NULL,
  `clienteBorro` bigint(20) DEFAULT NULL,
  `clienteEstado` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish2_ci DEFAULT 'ACTIVO',
  PRIMARY KEY (`clienteId`),
  UNIQUE KEY `CODIGO_UNICO` (`clienteCodigo`),
  UNIQUE KEY `UN_CLIENTE_X_PERSONA` (`clientePersona`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `clientes` */

/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;

insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (1,9,'CASALUD',3,'2016-01-20 08:36:54',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (2,10,'PREVER',3,'2016-01-20 09:08:45',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (3,11,'SERVICIOSINTEGRADOS',5,'2016-01-20 09:21:39',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (4,12,'SUBSANAR',3,'2016-01-20 09:34:15',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (5,13,'INTERASEO',5,'2016-01-20 09:43:08',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (6,14,'SERVIMETAL',5,'2016-01-20 09:49:47',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (7,15,'TORNIACCESORIOS',5,'2016-01-20 09:54:47',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (8,16,'INTEGRALHOMECARE',3,'2016-01-20 10:01:56',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (9,17,'ESREMCAL',5,'2016-01-20 10:42:19',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (10,18,'RITADAVILA',4,'2016-01-20 11:02:13',NULL,NULL,1,NULL,NULL,'ACTIVO');
insert  into `clientes`(`clienteId`,`clientePersona`,`clienteCodigo`,`clienteTipo`,`clienteCreado`,`clienteModificado`,`clienteBorrado`,`clienteCreo`,`clienteModifico`,`clienteBorro`,`clienteEstado`) values (11,19,'YOLANDALOPEZ',4,'2016-01-22 11:00:02',NULL,NULL,1,NULL,NULL,'ACTIVO');

/*!40000 ALTER TABLE  `clientes` ENABLE KEYS */;

/*Table structure for table `clientescontactos` */

DROP TABLE IF EXISTS `clientescontactos`;

CREATE TABLE `clientescontactos` (
  `clienteContactoId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `clienteContactoCliente` bigint(20) NOT NULL,
  `clienteContactoPersona` bigint(20) NOT NULL,
  `clienteContactoEtiquetas` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `clienteContactoRecibeEquipos` enum('SI','NO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'NO',
  `clienteContactoRecibeDeposito` enum('SI','NO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'NO',
  PRIMARY KEY (`clienteContactoId`),
  UNIQUE KEY `UQ_ClientesContactos_clienteContactoId` (`clienteContactoId`),
  KEY `IXFK_ClientesContactos_Clientes` (`clienteContactoCliente`),
  KEY `IXFK_ClientesContactos_Personas` (`clienteContactoPersona`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `clientescontactos` */

/*!40000 ALTER TABLE `clientescontactos` DISABLE KEYS */;

insert  into `clientescontactos`(`clienteContactoId`,`clienteContactoCliente`,`clienteContactoPersona`,`clienteContactoEtiquetas`,`clienteContactoRecibeEquipos`,`clienteContactoRecibeDeposito`) values (1,11,20,'PACIENTE','SI','NO');
insert  into `clientescontactos`(`clienteContactoId`,`clienteContactoCliente`,`clienteContactoPersona`,`clienteContactoEtiquetas`,`clienteContactoRecibeEquipos`,`clienteContactoRecibeDeposito`) values (2,11,21,'FAMILIAR','SI','SI');

/*!40000 ALTER TABLE  `clientescontactos` ENABLE KEYS */;

/*Table structure for table `componentes` */

DROP TABLE IF EXISTS `componentes`;

CREATE TABLE `componentes` (
  `componenteId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `componenteCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `componenteTitulo` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `componenteIcono` varchar(50) COLLATE utf8_spanish2_ci DEFAULT 'fa fa-dashboard',
  PRIMARY KEY (`componenteId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `componentes` */

/*!40000 ALTER TABLE `componentes` DISABLE KEYS */;

insert  into `componentes`(`componenteId`,`componenteCodigo`,`componenteTitulo`,`componenteIcono`) values (1,'ubicaciones','Ubicaciones','fa fa-dashboard');
insert  into `componentes`(`componenteId`,`componenteCodigo`,`componenteTitulo`,`componenteIcono`) values (2,'productos','Equipos y/o Productos','fa fa-dashboard');
insert  into `componentes`(`componenteId`,`componenteCodigo`,`componenteTitulo`,`componenteIcono`) values (3,'personas','Clientes','fa fa-dashboard');
insert  into `componentes`(`componenteId`,`componenteCodigo`,`componenteTitulo`,`componenteIcono`) values (4,'servicios','Servicios','fa fa-dashboard');
insert  into `componentes`(`componenteId`,`componenteCodigo`,`componenteTitulo`,`componenteIcono`) values (5,'consultas','Consultas / Reportes','fa fa-search');
insert  into `componentes`(`componenteId`,`componenteCodigo`,`componenteTitulo`,`componenteIcono`) values (7,'seguridad','Usuarios y Permisos','fa fa-dashboard');
insert  into `componentes`(`componenteId`,`componenteCodigo`,`componenteTitulo`,`componenteIcono`) values (8,'sistema','Configuracion','fa fa-dashboard');

/*!40000 ALTER TABLE  `componentes` ENABLE KEYS */;

/*Table structure for table `documentos` */

DROP TABLE IF EXISTS `documentos`;

CREATE TABLE `documentos` (
  `documentoId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `documentoCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `documentoTipo` int(10) NOT NULL,
  `documentoConsecutivo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `documentoTitulo` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `documentoUrl` text COLLATE utf8_spanish2_ci NOT NULL,
  `documentoDescargas` int(11) NOT NULL DEFAULT '0',
  `documentoFecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `documentoUsuario` bigint(20) NOT NULL,
  PRIMARY KEY (`documentoId`),
  UNIQUE KEY `UQ_Documentos_documentoId` (`documentoId`),
  UNIQUE KEY `UQ_Documentos_documentoCodigo` (`documentoCodigo`),
  KEY `IXFK_Documentos_Usuarios` (`documentoUsuario`),
  KEY `IXFK_Documentos_TipoDocumento` (`documentoTipo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `documentos` */

/*!40000 ALTER TABLE `documentos` DISABLE KEYS */;

/*!40000 ALTER TABLE  `documentos` ENABLE KEYS */;

/*Table structure for table `equipos` */

DROP TABLE IF EXISTS `equipos`;

CREATE TABLE `equipos` (
  `equipoId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `equipoTipo` int(10) NOT NULL,
  `equipoCodigo` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `equipoSerial` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `equipoTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `equipoCapacidad` varchar(12) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `equipoUrlQR` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `equipoUrlBARRAS` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `equipoObservaciones` text COLLATE utf8_spanish2_ci,
  `equipoUltimaUbicacionLatitud` varchar(50) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '11.227442290719976',
  `equipoUltimaUbicacionLongitud` varchar(50) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '-74.196954430081',
  `equipoUltimaUbicacionFecha` timestamp NULL DEFAULT NULL,
  `equipoEstadoServicio` int(10) DEFAULT '1',
  `equipoReciboServicio` bigint(20) DEFAULT NULL,
  `equipoClienteServicio` bigint(20) DEFAULT NULL,
  `equipoFechaCrea` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `equipoUsuarioCrea` bigint(20) NOT NULL,
  `equipoFechaModifica` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `equipoUsuarioModifica` bigint(20) DEFAULT NULL,
  `equipoFechaBorra` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `equipoUsuarioBorra` bigint(20) DEFAULT NULL,
  `equipoEstado` enum('ACTIVO','BORRADO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`equipoId`),
  UNIQUE KEY `UQ_Equipos_equipo_id` (`equipoId`),
  UNIQUE KEY `UQ_Equipos_equipo_codigo` (`equipoCodigo`),
  UNIQUE KEY `UQ_Equipos_equipoSerial` (`equipoSerial`),
  KEY `IXFK_Equipos_TiposEquipos` (`equipoTipo`),
  KEY `IXFK_Equipos_UsuarioCrear` (`equipoUsuarioCrea`),
  KEY `IXFK_Equipos_UsuarioModifica` (`equipoUsuarioModifica`),
  KEY `IXFK_Equipos_UsuarioBorra` (`equipoUsuarioBorra`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `equipos` */

/*!40000 ALTER TABLE `equipos` DISABLE KEYS */;

insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (1,1,'DDDDD','123456789','CILINDRO DE OXIGENO MEDICINAL','6 cm3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/123456789-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/123456789-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-20 11:30:04',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'BORRADO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (2,3,'COOOI','0193275','RESPIRONICS EVERFLO REF.102002','00 cm3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/0193275-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/0193275-bc.png','BOGOTA','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-21 08:01:57',1,'2016-01-21 08:03:59',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (3,3,'COOOII','0119821','RESPIRONICS EVERFLO  REF. 102002','00 cm3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/0119821-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/0119821-bc.png','LINDE','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-21 08:05:08',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (4,3,'COOOIII','0193111','RESPIRONICS EVERFLO REF. 1020002','00 cm3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/0193111-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/0193111-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-21 08:07:47',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (5,3,'COOOIV','0381510','RESPIRONICS EVERFLO REF. 1020002','00 cm3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/0381510-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/0381510-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-21 08:09:02',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (6,3,'COOOV','01931112','RESPIRONICS EVERFLO REF. 1020002','00 cm3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/01931112-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/01931112-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-21 08:10:21',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (7,2,'R0001','080108743','PROBASICS CGA 870 YUGO 0-8 L/MIN','8','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/080108743-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/080108743-bc.png','CUERPO COLOR VERDE','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 08:10:18',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (8,2,'R0002','DH101200668','ROSCOE MEDICAL CGA 540 ROSCA 0-8 L/M','8','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/DH101200668-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/DH101200668-bc.png','CUERPO VERDE SALIDA EN NIPLE','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 09:21:07',1,'2016-01-22 09:23:22',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (9,2,'R0003','LH88586','VICTOR ROSCA CGA 540 0-8 L/M','8','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/LH88586-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/LH88586-bc.png','DOS MANOMETROS ','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 09:23:11',1,'2016-01-22 09:34:03',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (11,2,'R0004','00011508','MADA MEDICAL CGA 870 YUGO 0-8 L/MIN','8','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/00011508-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/00011508-bc.png','CUERPO NIQUELADO SALIDA ROSCA','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 09:44:11',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (12,5,'RI001','125540','VICTOR ALTO FLUJO ALTA PRESION','0','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/125540-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/125540-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 09:49:20',1,'2016-01-22 17:11:19',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (13,6,'POM001','E319917','LUXFER 680 LTS ','680','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/E319917-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/E319917-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 13:41:38',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (18,5,'RI0002','15510','VICTOR ALTA PRESION ACETILENO','0','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/15510-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/15510-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 16:52:46',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (19,7,'C0001','0001','CARRITO CIL 680 L','0','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/0001-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/0001-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 16:53:32',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (20,2,'R0005','AI11091929','AIRIAL 0-8 L/MIN  ','8','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/AI11091929-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/AI11091929-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 17:08:47',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (21,2,'R0007','RO61301207Y','MADA MEDICAL ','15','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/RO61301207Y-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/RO61301207Y-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-22 17:32:50',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (22,1,'OI0001','AEMN51900','CILINDRO OXIGENO INDUSTRIAL 8M3','8','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/AEMN51900-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/AEMN51900-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 09:40:47',1,'2016-01-28 09:43:26',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (23,1,'OI0002','ACBU40665','CILINDRO OXIGENO INDUSTRIAL 8M3','8','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/ACBU40665-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/ACBU40665-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 09:41:22',1,'2016-01-28 09:43:36',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (24,1,'OI0003','A29404595','CILINDRO OXIGENO INDUSTRIAL 8M3','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/A29404595-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/A29404595-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 09:42:37',1,'2016-01-28 09:43:47',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (25,8,'AR0001','A920264566','CILINDRO ARGON INDUSTRIAL ','6.5 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/A920264566-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/A920264566-bc.png','PROTECTOR. ','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 09:44:43',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (26,8,'AR0002','3638950','CILINDO ARGON INDUSTRIAL ','7 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/3638950-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/3638950-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 09:46:00',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (27,10,'OM0001','8109420','CILINDRO OXIGENO MEDICINAL MEDIANO','3 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/8109420-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/8109420-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:18:59',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (28,10,'OM0002','1289','CILINDRO OXIGENO MEDICINAL MEDIANO','3 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/1289-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/1289-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:19:49',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (29,10,'OM0003','41072','CILINDRO DE OXIGENO MEDICINAL MEDIANO','3 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/41072-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/41072-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:20:38',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (30,10,'OM0004','39759','CILINDRO DE OXIGENO MEDICINAL MEDIANO','3 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/39759-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/39759-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:21:22',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (31,8,'AR0003','C2396740','CILINDRO ARGON INDUSTRIAL','6.5 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/C2396740-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/C2396740-bc.png','45.9 KGS PESO NETO. PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:26:36',1,'2016-01-28 13:19:34',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (32,11,'MIX0001','88001369','CILINDRO DE MIX ','8.7 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/88001369-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/88001369-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:29:12',1,'2016-01-28 10:30:23',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (33,11,'MIX0002','A88001341','CILINDRO DE MIX INDUSTRIAL','8.7 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/A88001341-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/A88001341-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:30:02',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (34,11,'MIX0003','A870072','CILINDRO MIX INDUSTRIAL','8.7 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/A870072-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/A870072-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:31:27',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (35,11,'MIX0004','ACBY8102','CILINDRO MIX INDUSTRIAL','8.7 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/ACBY8102-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/ACBY8102-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:46:07',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (36,8,'AR0004','149012','CILINDRO ARGON INDUSTRIAL','6.5 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/149012-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/149012-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:47:32',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (37,11,'MIX0005','0099','CILINDRO MIX INDUSTRIAL ','8.7 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/0099-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/0099-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:48:34',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (39,8,'AR0005','8294480','CILINDRO ARGON INDUSTRIAL','6.5 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/8294480-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/8294480-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:51:41',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (40,8,'AR0006','204190','CILINDRO ARGON INDUSTRIAL','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/204190-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/204190-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:52:23',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (41,9,'N0001','629582','CILINDRO NITROGENO INDUSTRIAL','6.5 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/629582-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/629582-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:53:10',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (42,9,'N0002','100002','CILINDRO NITROGENO INDUSTRIAL','6.5 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/100002-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/100002-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:53:44',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (43,9,'N0003','250234','CILINDRO NITROGENO INDUSTRIAL','6.5 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/250234-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/250234-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:54:26',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (44,9,'N0004','413334','CILINDRO NITROGENO INDUSTRIAL','6.5 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/413334-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/413334-bc.png','SIN ROSCA. MANTENIMIENTO.','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 10:56:24',1,'2016-01-28 10:56:50',1,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (46,1,'OI0004','32006','CILINDRO OXIGENO INDUSTRIAL 8M3','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/32006-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/32006-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 11:09:39',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (47,1,'OI0005','9670','CILINDRO OXIGENO INDUSTRIAL 8M3','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/9670-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/9670-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 11:10:11',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (48,9,'N0005','P185137','CILINDRO NITROGENO INDUSTRIAL','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/P185137-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/P185137-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 11:17:09',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (50,9,'N0006','P022041','CILINDRO NITROGENO INDUSTRIAL','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/P022041-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/P022041-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 13:18:01',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (52,8,'N0007','8740045','CILINDRO ARGON INDUSTRIAL','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/8740045-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/8740045-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 13:20:23',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (53,8,'N0008','57431','CILINDRO ARGON INDUSTRIAL','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/57431-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/57431-bc.png','PROTECTOR','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 13:21:18',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (54,8,'AR0009','866895','CILINDRO ARGON INDUSTRIAL','8 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/866895-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/866895-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 13:23:57',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (57,11,'MIX0006','88003134','CILINDRO MIX INDUSTRIAL','8.7 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/88003134-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/88003134-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 13:28:04',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `equipos`(`equipoId`,`equipoTipo`,`equipoCodigo`,`equipoSerial`,`equipoTitulo`,`equipoCapacidad`,`equipoUrlQR`,`equipoUrlBARRAS`,`equipoObservaciones`,`equipoUltimaUbicacionLatitud`,`equipoUltimaUbicacionLongitud`,`equipoUltimaUbicacionFecha`,`equipoEstadoServicio`,`equipoReciboServicio`,`equipoClienteServicio`,`equipoFechaCrea`,`equipoUsuarioCrea`,`equipoFechaModifica`,`equipoUsuarioModifica`,`equipoFechaBorra`,`equipoUsuarioBorra`,`equipoEstado`) values (58,11,'MIX0007','A657375','CILINDRO MIX INDUSTRIAL','8.7 M3','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/qrcode/A657375-qr.png','http://siom.oximeiser.com/archivos/oximeiser/productos/equipos/barcode/A657375-bc.png','','11.227442290719976','-74.196954430081',NULL,1,NULL,NULL,'2016-01-28 13:28:49',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');

/*!40000 ALTER TABLE  `equipos` ENABLE KEYS */;

/*Table structure for table `equiposestados` */

DROP TABLE IF EXISTS `equiposestados`;

CREATE TABLE `equiposestados` (
  `equipoEstadoId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `equipoEstadoCodigo` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `equipoEstadoTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`equipoEstadoId`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `equiposestados` */

/*!40000 ALTER TABLE `equiposestados` DISABLE KEYS */;

insert  into `equiposestados`(`equipoEstadoId`,`equipoEstadoCodigo`,`equipoEstadoTitulo`) values (1,'DISPONIBLE','DISPONIBLE');
insert  into `equiposestados`(`equipoEstadoId`,`equipoEstadoCodigo`,`equipoEstadoTitulo`) values (2,'ENSERVICIO','EN SERVICIO');
insert  into `equiposestados`(`equipoEstadoId`,`equipoEstadoCodigo`,`equipoEstadoTitulo`) values (3,'DESHABILIT','NO DISPONIBLE');
insert  into `equiposestados`(`equipoEstadoId`,`equipoEstadoCodigo`,`equipoEstadoTitulo`) values (4,'MANTENIMIE','EN MANTENIMIENTO');

/*!40000 ALTER TABLE  `equiposestados` ENABLE KEYS */;

/*Table structure for table `equiposubicaciones` */

DROP TABLE IF EXISTS `equiposubicaciones`;

CREATE TABLE `equiposubicaciones` (
  `equipoUbicacionId` bigint(21) unsigned NOT NULL AUTO_INCREMENT,
  `equipoUbicacion` int(10) NOT NULL,
  `equipoUbicacionFecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `equipoUbicacionLatitud` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `equipoUbicacionLongitud` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `equipoUbicacionUsuario` bigint(20) NOT NULL,
  PRIMARY KEY (`equipoUbicacionId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `equiposubicaciones` */

/*!40000 ALTER TABLE `equiposubicaciones` DISABLE KEYS */;

/*!40000 ALTER TABLE  `equiposubicaciones` ENABLE KEYS */;

/*Table structure for table `funciones` */

DROP TABLE IF EXISTS `funciones`;

CREATE TABLE `funciones` (
  `funcionId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `funcionCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `funcionNombre` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `funcionModulo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'sistema',
  `funcionLogica` varchar(50) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'informacion',
  `funcionTarea` varchar(50) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'mostrarInformacion',
  `funcionMenu` enum('SI','NO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'SI',
  `funcionPadre` int(10) NOT NULL DEFAULT '0',
  `funcionOrden` int(10) NOT NULL DEFAULT '99',
  PRIMARY KEY (`funcionId`),
  UNIQUE KEY `UQ_FuncionesSistema_funcionId` (`funcionId`),
  UNIQUE KEY `UQ_FuncionesSistema_funcionCodigo` (`funcionCodigo`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `funciones` */

/*!40000 ALTER TABLE `funciones` DISABLE KEYS */;

insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (1,'mostrarInfoSistema','Ver informacion del sistema','sistema','informacion','mostrarInformacion','NO',0,99);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (2,'parametros','Parametros del Sistema','sistema','parametros','mostrarParametros','SI',0,99);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (3,'cargosEmpleadosListado','Cargos de Empleados','seguridad','cargosEmpleados','mostrarTodos','SI',0,1);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (4,'tiposEquiposListado','Tipos de Equipos o Productos','productos','tiposEquipos','mostrarTodos','SI',0,1);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (5,'consecutivosListado','Secuencias o consecutivos','sistema','consecutivos','mostrarTodos','SI',0,99);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (6,'tipoClienteListado','Tipos de Clientes','personas','tiposClientes','mostrarTodos','SI',0,1);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (7,'usuariosListado','Empleados','seguridad','empleados','mostrarTodos','SI',0,2);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (8,'equiposListados','Equipos Registrados','productos','equipos','mostrarTodos','SI',0,2);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (9,'consultaRegistros','Consulta de Recibos','consultas','recibos','panelBusqueda','SI',0,1);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (10,'recibosListado','Recibos ','servicios','recibos','mostrarTodos','NO',0,2);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (11,'servicioEquipoNuevo','Nuevo Servicio','servicios','equipos','nuevo','SI',0,0);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (12,'recibosAuditoria','Recibos Modificados','servicios','recibos','panelAuditoria','NO',0,5);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (13,'calendarioRecogida','Calendario de recoleccion','servicios','calendario','recoleccion','SI',0,4);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (14,'clientesListado','Clientes Registrados','personas','clientes','mostrarTodos','SI',0,2);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (15,'clientesContactos','Contactos Registrados','personas','clientes','contactos','NO',0,3);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (16,'cilentesMapa','Mapa de Clientes','personas','clientes','mapa','SI',0,4);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (17,'reporteMovimientos','Reportes de Movimientos','consultas','movimientos','panelMovimientos','SI',0,2);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (18,'mapaGeneral','Mapa General','ubicaciones','mapa','mostrar','NO',0,99);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (19,'serviciosEquipos','Servicios o Recibos','servicios','equipos','mostrarTodos','SI',0,1);
insert  into `funciones`(`funcionId`,`funcionCodigo`,`funcionNombre`,`funcionModulo`,`funcionLogica`,`funcionTarea`,`funcionMenu`,`funcionPadre`,`funcionOrden`) values (20,'depositosEquipos','Depositos','servicios','depositos','mostrarTodos','SI',0,3);

/*!40000 ALTER TABLE  `funciones` ENABLE KEYS */;

/*Table structure for table `personas` */

DROP TABLE IF EXISTS `personas`;

CREATE TABLE `personas` (
  `personaId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `personaTipoIdentificacion` int(10) NOT NULL,
  `personaIdentificacion` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `personaRazonSocial` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `personaNombreComercial` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `personaNombres` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `personaApellidos` varchar(100) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `personaDireccion` text COLLATE utf8_spanish2_ci,
  `personaTelefono` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `personaCelular` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `personaCorreoElectronico` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `personaLatitud` varchar(50) COLLATE utf8_spanish2_ci DEFAULT '11.2272989',
  `personaLongitud` varchar(50) COLLATE utf8_spanish2_ci DEFAULT '-74.1967533',
  `personaObservaciones` text COLLATE utf8_spanish2_ci,
  `personaLogo` text COLLATE utf8_spanish2_ci,
  `personaFotoReferencia` text COLLATE utf8_spanish2_ci,
  `personaFirmaEscaneada` text COLLATE utf8_spanish2_ci,
  `personaFechaCreado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `personaUsuarioCrea` bigint(20) NOT NULL,
  `personaFechaModificado` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `personaUsuarioModifica` bigint(20) DEFAULT NULL,
  `personaFechaBorrado` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `personaUsuarioBorra` bigint(20) DEFAULT NULL,
  `personaEstado` enum('ACTIVO','BORRADO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`personaId`),
  UNIQUE KEY `UQ_personas_personaId` (`personaId`),
  UNIQUE KEY `UQ_personas_personaIdentificacion` (`personaIdentificacion`),
  KEY `IXFK_personas_TipoIdentificacion` (`personaTipoIdentificacion`),
  KEY `IXFK_personas_UsuarioCrea` (`personaUsuarioCrea`),
  KEY `IXFK_personas_UsuarioModifica` (`personaUsuarioModifica`),
  KEY `IXFK_personas_UsuarioBorra` (`personaUsuarioBorra`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `personas` */

/*!40000 ALTER TABLE `personas` DISABLE KEYS */;

insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (1,1,'84459288','Juan Pablo Llinás Ramírez','Puro Ingenio Samario','Juan Pablo','Llinás Ramírez','Av Ferrocarril #29e-101, Barrio el Mayor','420-2768','301-7544089','info@puroingeniosamario.com.co','11.247481641959366','-74.19599801301956','','/archivos/oximeiser/img/logo-aqui.png','/archivos/oximeiser/img/logo-aqui.png','/archivos/oximeiser/empleados/firma.png','2015-10-08 21:48:14',0,'2015-11-01 13:29:38',0,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (2,1,'1082978434','Dayana Vidal Jiménez','Dayana','Dayana','Vidal Jiménez','Av. Ferrocarril No. 29-43 \r\nPortal de la 19.','420-5002','300-7770191','dvidal@oximeiser.com','11.227442290719976','','OXIMED MEISER SAS\r\nAv. Ferrocarril No. 29-43 \r\nPortal de la 19.\r\nTel.1. (5) (4205002)\r\nTel.2. (5) (4205003)\r\nCel. 300 777 0191\r\nwww.oximeiser.com\r\nSanta Marta - Colombia','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-123456789-569cf7a794113.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/foto-1-123456789-569cf7a795614.jpg',NULL,'2016-01-18 08:33:11',0,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (3,1,'12555717','WILSON  OLMOS BOLAÑO','','WILSON ','OLMOS BOLAÑO',' ','','301-204690','DVIDAL@OXIMEISER.COM','11.227442290719976','','','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-12555717-569d21852b71d.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/foto-1-12555717-569d21852bdef.jpg',NULL,'2016-01-18 11:31:49',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (4,1,'57433944','BETTY PATRICIA JIMENEZ IBAÑEZ','BETTY','BETTY PATRICIA','JIMENEZ IBAÑEZ','AVENIDA DEL FERROCARRIL No.29C43','420-5002','300-7766774','HUGOVIDALCASTRO@YAHOO.COM.CO','11.227442290719976','','','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-57433944-569e626fe83dc.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/foto-1-57433944-569e626fe984f.JPG',NULL,'2016-01-19 10:21:03',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (5,1,'1082905679','MIGUEL ANGEL HERNANDEZ ANOCHE','MIGUE','MIGUEL ANGEL','HERNANDEZ ANOCHE','AVENIDA DEL FERROCARRIL No.29C43','420-5002','300-4978857','MHERNANDEZ@OXIMEISER.COM','11.227442290719976','','','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-1082905679-569e6c046e545.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/foto-1-1082905679-569e6c0489f54.jpg',NULL,'2016-01-19 11:01:56',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (6,1,'39143542','CAROLINA DEL CARMEN MUNÑOZ MONTENEGRO','CAROLINA','CAROLINA DEL CARMEN','MUNÑOZ MONTENEGRO','AVENIDA DEL FERROCARRIL NO29C43','420-5002','','CMUNOZ@OXIMEISER.COM','11.227442290719976','','','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-39143542-569e6d089e2ab.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/foto-1-39143542-569e6d089e5a1.jpg',NULL,'2016-01-19 11:06:16',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (7,1,'16856763','HUGO VIDAL CASTRO','HUGO','HUGO','VIDAL CASTRO','avenida del ferrocarril no29c43','420-5002','316-2455225','HUGOVIDALCASTRO@YAHOO.COM.CO','11.227442290719976','','','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-16856763-569e6d9f53c96.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/foto-1-16856763-569e6d9f54102.jpg',NULL,'2016-01-19 11:08:47',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (8,1,'36693762','MARLI ISABEL ACOSTA MUÑOZ','MARLI','MARLI ISABEL','ACOSTA MUÑOZ','AVENIDA DEL FERROCARRIL NO29C43','420-5002','300-8463414','DVIDAL@OXIMEISER.COM','11.227442290719976','','','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-36693762-569e6e78a4af1.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/foto-1-36693762-569e6e78a4de3.jpg',NULL,'2016-01-19 11:12:24',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (9,2,'900477943','CASALUD  IPS ','CASALUD','CASALUD ','IPS ','CR 12 26B 75 LC 103 CC PLUS CENTER                PLUS CENTER BRR BAVARIA            ','','318-3546297','CASALUD.I.P.S@HOTMAIL.COM','11.235506473558338','-74.20537099242205','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-900477943-569f9b864c0a5.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-900477943-569f9b8650792.png',NULL,'2016-01-20 08:36:54',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (10,2,'900635194','PREVER MAGDALENA IPS SAS','PREVER','PREVER MAGDALENA','IPS SAS','CALLE 22 NO. 14-17 2 PISO     ','421-3506','300-8437808','admpreverips@gmail.com','11.236058941743957','-74.20034319162369','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-900635194-569fa2fd39db1.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-900635194-569fa2fd3b112.png',NULL,'2016-01-20 09:08:45',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (11,2,'900214748','SERVICIOS INTEGRADOS OUTSOURCING SAS','SERVICIOS INTEGRADOS','SERVICIOS INTEGRADOS','OUTSOURCING SAS','CALLE 136 CRA 5 EZQ SECTOR BELLO SOL    ','438-0422','','YUDIS.FONTALVO@SERVICIOSINTEGRADOS.NET.CO','11.139176723619592','-74.22431141138071','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-900214748-569fa6039de14.gif','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-900214748-569fa6039e0b5.png',NULL,'2016-01-20 09:21:39',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (12,2,'900194140','SUBSANAR SALUD IPS ','SUBSANAR','SUBSANAR SALUD','IPS ','AV. DEL LIBERTADOR CRA 16 D No 16D 49   ','420-5315','300-8437801','subsanarsaludips@hotmail.com','11.243225147438459','-74.19854074716574','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-900194140-569fa8f7e05c1.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-900194140-569fa8f7e1c34.png',NULL,'2016-01-20 09:34:15',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (13,2,'819000939','INTERASEO SA','INTERASEO','INTERASEO','SA','KM2 VIA GAIRA ALUMBRADO PUBLICO   ','434-6234','','comprassta@interaseo.com.co','11.208634196831662','-74.1927364468574','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-819000939-569fab0c339df.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-819000939-569fab0c33d28.png',NULL,'2016-01-20 09:43:08',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (14,2,'900476318','SERVIMETAL CP SAS','SERVIMETAL','SERVIMETAL','CP SAS','CLL 9 No 12A -36                                  BARRIO MIRAFLORES        ','421-2015','','cartera@servimetalcp.com','11.246823967679303','-74.20273572206492','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-900476318-569fac9b56fc3.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-900476318-569fac9b58ff0.png',NULL,'2016-01-20 09:49:47',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (15,2,'15367642','ALMACEN Y TALLER TORNIACCESORIOS','EVER NAVARRO/TORNIACCESORIO','ALMACEN Y TALLER','TORNIACCESORIOS','CLL PRINCIPAL CRA3 121 RIOFRIO         ','','311-6595646','torniaccesorios@hotmail.com','11.24034184967624','-74.19599801301956','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-15367642-569fadc76ef6f.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-15367642-569fadc7716fc.png',NULL,'2016-01-20 09:54:47',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (16,2,'900540946','INTEGRAL HOME CARE SAS','INTEGRAL HOME CARE','INTEGRAL HOME CARE','SAS','CL 51 No.38-43   ','','301-4822187','INTEGRALHOMECARESM@HOTMAIL.COM','11.2347119698362','-74.20067578554153','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-900540946-569faf7483b89.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-900540946-569faf7483edb.png',NULL,'2016-01-20 10:01:56',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (17,2,'815004411','ESPECIALISTAS EN MANTENIMIENTO REPARACION Y MONTAJES SAS','ESREMCAL','ESPECIALISTAS EN MANTENIMIENTO REPARACION Y MONTAJES','SAS','CRA 38A # 75B-42  BARRANQUILLA                    CRA 28 69-79 PALMIRA VALLE DEL CAUCA     PROYECTO: TERMOGUAJIRA - GECELCA','304-9835','310-4008944','auxiliarmttoequipos@esremcal.com','11.24034184967624','-74.19599801301956','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-2-815004411-569fb8eb36211.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-2-815004411-569fb8eb3752b.png',NULL,'2016-01-20 10:42:19',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (18,1,'26659062','RITA ARMENTA DE DAVILA ','RITA ','RITA','ARMENTA DE DAVILA ','CRA. 1 No. 24-64              ','421-1787','314-5962576','OXIMEISER@YAHOO.ES','11.238310896351424','-74.21728938817978','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-1-26659062-569fbd950789f.png','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-1-26659062-569fbd9509027.png',NULL,'2016-01-20 11:02:13',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (19,1,'63286241','YOLANDA LOPEZ GUIZA','','YOLANDA','LOPEZ GUIZA','MZ I CASA 1 VILLA DEL MAR SANTA MARTA','430-0467','317-6679879','DVIDAL@OXIMEISER.COM','11.24034184967624','-74.19599801301956','','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/logo-1-63286241-56a260121d9e4.jpg','http://siom.oximeiser.com/archivos/oximeiser/personas/clientes/foto-1-63286241-56a260122895d.jpg',NULL,'2016-01-22 11:00:02',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (20,1,'2208615','RAMON EXPEDITO LOPEZ','','RAMON','EXPEDITO LOPEZ','','','','','','','','','/archivos/oximeiser/personas/referencia.jpg',NULL,'2016-01-22 11:00:02',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');
insert  into `personas`(`personaId`,`personaTipoIdentificacion`,`personaIdentificacion`,`personaRazonSocial`,`personaNombreComercial`,`personaNombres`,`personaApellidos`,`personaDireccion`,`personaTelefono`,`personaCelular`,`personaCorreoElectronico`,`personaLatitud`,`personaLongitud`,`personaObservaciones`,`personaLogo`,`personaFotoReferencia`,`personaFirmaEscaneada`,`personaFechaCreado`,`personaUsuarioCrea`,`personaFechaModificado`,`personaUsuarioModifica`,`personaFechaBorrado`,`personaUsuarioBorra`,`personaEstado`) values (21,1,'63295210','ELSA LOPEZ','','ELSA','LOPEZ','','','','','','','','','/archivos/oximeiser/personas/referencia.jpg',NULL,'2016-01-22 11:00:02',1,'0000-00-00 00:00:00',NULL,'0000-00-00 00:00:00',NULL,'ACTIVO');

/*!40000 ALTER TABLE  `personas` ENABLE KEYS */;

/*Table structure for table `recibocontrolcambios` */

DROP TABLE IF EXISTS `recibocontrolcambios`;

CREATE TABLE `recibocontrolcambios` (
  `reciboCambioId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reciboCambioServicio` bigint(20) NOT NULL,
  `reciboCambioFecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reciboCambioMotivo` int(10) NOT NULL,
  `reciboCambioObservacion` text COLLATE utf8_spanish2_ci NOT NULL,
  `reciboCambioUsuario` bigint(20) NOT NULL,
  `reciboCambioDatosAntes` text COLLATE utf8_spanish2_ci,
  `reciboCambioDatosDespues` text COLLATE utf8_spanish2_ci,
  PRIMARY KEY (`reciboCambioId`),
  UNIQUE KEY `UQ_ReciboControlCambios_reciboCambioId` (`reciboCambioId`),
  KEY `IXFK_ReciboControlCambios_ReciboServicio` (`reciboCambioServicio`),
  KEY `IXFK_ReciboControlCambios_Usuarios` (`reciboCambioUsuario`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `recibocontrolcambios` */

/*!40000 ALTER TABLE `recibocontrolcambios` DISABLE KEYS */;

/*!40000 ALTER TABLE  `recibocontrolcambios` ENABLE KEYS */;

/*Table structure for table `recibodepositos` */

DROP TABLE IF EXISTS `recibodepositos`;

CREATE TABLE `recibodepositos` (
  `reciboDepositoId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reciboServicioDeposito` bigint(20) NOT NULL COMMENT 'El recibo asociado a el deposito entregado',
  `reciboDepositoTipo` int(10) DEFAULT NULL,
  `reciboDepositoValor` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `reciboDepositoObservacion` text COLLATE utf8_spanish2_ci,
  `reciboDepositoDocIngreso` bigint(20) DEFAULT NULL,
  `reciboDepositoDocEgreso` bigint(20) DEFAULT NULL,
  `reciboDepositoRecibido` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reciboDepositoRecibio` bigint(20) NOT NULL,
  `reciboDepositoDevueltoA` bigint(20) DEFAULT NULL,
  `reciboDepositoDevuelto` timestamp NULL DEFAULT NULL,
  `reciboDepositoDevolvio` bigint(20) DEFAULT NULL,
  `reciboDepositoRetenido` timestamp NULL DEFAULT NULL,
  `reciboDepositoRetiene` bigint(20) DEFAULT NULL,
  `reciboDepositoAnulado` timestamp NULL DEFAULT NULL,
  `reciboDepositoAnula` bigint(20) DEFAULT NULL,
  `reciboDepositoEstado` enum('RECIBIDO','DEVUELTO','RETENIDO','ANULADO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'RECIBIDO' COMMENT 'Este púede ser RETENIDO, DEVUELTO o ENTREGADO Retenido es en caso de que exista alguna contraoversia con l uso del equipo.',
  PRIMARY KEY (`reciboDepositoId`),
  UNIQUE KEY `UQ_ReciboDepositos_reciboDepositoId` (`reciboDepositoId`),
  KEY `IXFK_ReciboDepositos_ReciboServicio` (`reciboServicioDeposito`),
  KEY `IXFK_ReciboDepositos_UsuarioRecibio` (`reciboDepositoRecibio`),
  KEY `IXFK_ReciboDepositos_UsuarioDevolvio` (`reciboDepositoDevolvio`),
  KEY `IXFK_ReciboDepositos_Usuarios` (`reciboDepositoRetiene`),
  KEY `IXFK_ReciboDepositos_DocumentoEgreso` (`reciboDepositoDocEgreso`),
  KEY `IXFK_ReciboDepositos_DocumentoIngreso` (`reciboDepositoDocIngreso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `recibodepositos` */

/*!40000 ALTER TABLE `recibodepositos` DISABLE KEYS */;

/*!40000 ALTER TABLE  `recibodepositos` ENABLE KEYS */;

/*Table structure for table `reciboequipos` */

DROP TABLE IF EXISTS `reciboequipos`;

CREATE TABLE `reciboequipos` (
  `reciboEquipoId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reciboServicioEquipo` bigint(20) NOT NULL COMMENT 'este es el id del recibo del servicio',
  `reciboEquipoMovimiento` int(10) NOT NULL COMMENT 'Indica si el movimento fue de entrega, recogija, perdida, etc... Estarn definido en otra tabal para esto',
  `reciboEquipoEnServicio` int(10) NOT NULL COMMENT 'Este es el equipo de este recibo del servicio',
  PRIMARY KEY (`reciboEquipoId`),
  UNIQUE KEY `UQ_MovimientosDetalles_movimientoDetalleId` (`reciboEquipoId`),
  KEY `IXFK_ReciboEquipos_ReciboServicio` (`reciboServicioEquipo`),
  KEY `IXFK_ReciboEquipos_TiposMoviminetos` (`reciboEquipoMovimiento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci COMMENT='Todos los movimientos de los equpos o productos que se entregan o reciben';

/*Data for the table `reciboequipos` */

/*!40000 ALTER TABLE `reciboequipos` DISABLE KEYS */;

/*!40000 ALTER TABLE  `reciboequipos` ENABLE KEYS */;

/*Table structure for table `reciboservicio` */

DROP TABLE IF EXISTS `reciboservicio`;

CREATE TABLE `reciboservicio` (
  `reciboId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reciboNumero` bigint(20) NOT NULL,
  `reciboFechaServicio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `reciboFechaRecogida` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reciboCliente` bigint(20) NOT NULL,
  `reciboDireccion` text COLLATE utf8_spanish2_ci NOT NULL,
  `reciboUsuarioAtiende` bigint(20) NOT NULL,
  `reciboLatitud` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `reciboLongitud` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `reciboEstado` enum('ACTIVO','ANULADO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  `reciboFechaCreado` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reciboUsuarioCrea` bigint(20) NOT NULL,
  `reciboFechaAnulado` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reciboUsuarioAnula` bigint(20) DEFAULT NULL,
  `reciboDocumento` bigint(20) NOT NULL,
  PRIMARY KEY (`reciboId`),
  UNIQUE KEY `UQ_ReciboServicio_reciboId` (`reciboId`),
  UNIQUE KEY `UQ_ReciboServicio_reciboNumero` (`reciboNumero`),
  KEY `IXFK_ReciboServicio_Clientes` (`reciboCliente`),
  KEY `IXFK_ReciboServicio_UsuarioAtiende` (`reciboUsuarioAtiende`),
  KEY `IXFK_ReciboServicio_UsuarioCreador` (`reciboUsuarioCrea`),
  KEY `IXFK_ReciboServicio_UsuarioAnula` (`reciboUsuarioAnula`),
  KEY `IXFK_ReciboServicio_Documentos` (`reciboDocumento`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `reciboservicio` */

/*!40000 ALTER TABLE `reciboservicio` DISABLE KEYS */;

/*!40000 ALTER TABLE  `reciboservicio` ENABLE KEYS */;

/*Table structure for table `recibosserviciosequipos` */

DROP TABLE IF EXISTS `recibosserviciosequipos`;

CREATE TABLE `recibosserviciosequipos` (
  `reciboId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reciboServicio` bigint(20) DEFAULT NULL,
  `reciboNumero` varchar(20) COLLATE utf8_spanish2_ci NOT NULL,
  `reciboFechaServicio` timestamp NULL DEFAULT NULL,
  `reciboFechaRecogida` date DEFAULT NULL,
  `reciboCliente` bigint(20) NOT NULL,
  `reciboReferencia` bigint(20) DEFAULT NULL,
  `reciboDireccion` text COLLATE utf8_spanish2_ci NOT NULL,
  `reciboUsuarioAtiende` bigint(20) NOT NULL,
  `reciboLatitud` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `reciboLongitud` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `reciboEstado` enum('ACTIVO','ANULADO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  `reciboFechaCreado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `reciboUsuarioCrea` bigint(20) NOT NULL,
  `reciboFechaAnulado` timestamp NULL DEFAULT NULL,
  `reciboUsuarioAnula` bigint(20) DEFAULT NULL,
  `reciboDocumento` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`reciboId`),
  UNIQUE KEY `UQ_ReciboServicio_reciboId` (`reciboId`),
  UNIQUE KEY `UQ_ReciboServicio_reciboNumero` (`reciboNumero`),
  KEY `IXFK_ReciboServicio_Clientes` (`reciboCliente`),
  KEY `IXFK_ReciboServicio_UsuarioAtiende` (`reciboUsuarioAtiende`),
  KEY `IXFK_ReciboServicio_UsuarioCreador` (`reciboUsuarioCrea`),
  KEY `IXFK_ReciboServicio_UsuarioAnula` (`reciboUsuarioAnula`),
  KEY `IXFK_ReciboServicio_Documentos` (`reciboDocumento`),
  KEY `IXfk_SERVICIO_DEL_RECIBO` (`reciboServicio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `recibosserviciosequipos` */

/*!40000 ALTER TABLE `recibosserviciosequipos` DISABLE KEYS */;

/*!40000 ALTER TABLE  `recibosserviciosequipos` ENABLE KEYS */;

/*Table structure for table `servicios` */

DROP TABLE IF EXISTS `servicios`;

CREATE TABLE `servicios` (
  `servicioId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `servicioTipo` enum('ARRIENDO EQUIPOS','TANQUEADO','VENTA EQUIPOS') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ARRIENDO EQUIPOS',
  `servicioCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `servicioCreado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `servicioCreo` bigint(20) NOT NULL,
  `servicioModificado` timestamp NULL DEFAULT NULL,
  `servicioModifico` bigint(20) DEFAULT NULL,
  `servicioBorrado` timestamp NULL DEFAULT NULL,
  `servicioBorro` bigint(20) DEFAULT NULL,
  `servicioAnulado` timestamp NULL DEFAULT NULL,
  `servicioAnulo` bigint(20) DEFAULT NULL,
  `servicioDevuelto` timestamp NULL DEFAULT NULL,
  `servicioDevolvio` bigint(20) DEFAULT NULL,
  `servicioEstado` enum('ACTIVO','BORRADO','ANULADO','DEVUELTO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`servicioId`),
  UNIQUE KEY `UQ_CODIGO` (`servicioCodigo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `servicios` */

/*!40000 ALTER TABLE `servicios` DISABLE KEYS */;

/*!40000 ALTER TABLE  `servicios` ENABLE KEYS */;

/*Table structure for table `tiposclientes` */

DROP TABLE IF EXISTS `tiposclientes`;

CREATE TABLE `tiposclientes` (
  `tipoClienteId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipoClienteCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoClienteTitulo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoClienteDefinicion` text COLLATE utf8_spanish2_ci,
  `tipoClienteEstado` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`tipoClienteId`),
  UNIQUE KEY `UQ_TipoCLiente_tipoClienteId` (`tipoClienteId`),
  UNIQUE KEY `UQ_TipoCLiente_tipoClienteCodigo` (`tipoClienteCodigo`),
  UNIQUE KEY `UQ_TipoCLiente_tipoClienteTitulo` (`tipoClienteTitulo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `tiposclientes` */

/*!40000 ALTER TABLE `tiposclientes` DISABLE KEYS */;

insert  into `tiposclientes`(`tipoClienteId`,`tipoClienteCodigo`,`tipoClienteTitulo`,`tipoClienteDefinicion`,`tipoClienteEstado`) values (1,'NORMAL','Normal','','INACTIVO');
insert  into `tiposclientes`(`tipoClienteId`,`tipoClienteCodigo`,`tipoClienteTitulo`,`tipoClienteDefinicion`,`tipoClienteEstado`) values (2,'SALUD','Salud','','INACTIVO');
insert  into `tiposclientes`(`tipoClienteId`,`tipoClienteCodigo`,`tipoClienteTitulo`,`tipoClienteDefinicion`,`tipoClienteEstado`) values (3,'MEDICINAL','CLIENTE MEDICINAL INSTITUCIONAL','','ACTIVO');
insert  into `tiposclientes`(`tipoClienteId`,`tipoClienteCodigo`,`tipoClienteTitulo`,`tipoClienteDefinicion`,`tipoClienteEstado`) values (4,'PACIENTE','CLIENTE MEDICINAL PARTICULAR','','ACTIVO');
insert  into `tiposclientes`(`tipoClienteId`,`tipoClienteCodigo`,`tipoClienteTitulo`,`tipoClienteDefinicion`,`tipoClienteEstado`) values (5,'INDUSTRIAL','CLIENTE INDUSTRIAL EMPRESARIAL','','ACTIVO');
insert  into `tiposclientes`(`tipoClienteId`,`tipoClienteCodigo`,`tipoClienteTitulo`,`tipoClienteDefinicion`,`tipoClienteEstado`) values (6,'PERSONAS','CLIENTE INDUSTRIAL PERSONAS','','ACTIVO');

/*!40000 ALTER TABLE  `tiposclientes` ENABLE KEYS */;

/*Table structure for table `tiposdepositos` */

DROP TABLE IF EXISTS `tiposdepositos`;

CREATE TABLE `tiposdepositos` (
  `depositoId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `depositoCodigo` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `depositoTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `depositoValor` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`depositoId`),
  UNIQUE KEY `UQ_CODIGO_DEPOSITO` (`depositoCodigo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `tiposdepositos` */

/*!40000 ALTER TABLE `tiposdepositos` DISABLE KEYS */;

insert  into `tiposdepositos`(`depositoId`,`depositoCodigo`,`depositoTitulo`,`depositoValor`) values (1,'BASICO','Basico $10mil por Equipo','10000');
insert  into `tiposdepositos`(`depositoId`,`depositoCodigo`,`depositoTitulo`,`depositoValor`) values (2,'TARIFA1','$15mil por Equipo','15000');
insert  into `tiposdepositos`(`depositoId`,`depositoCodigo`,`depositoTitulo`,`depositoValor`) values (3,'TARIFA2','$9MIL por Equipo','9000');

/*!40000 ALTER TABLE  `tiposdepositos` ENABLE KEYS */;

/*Table structure for table `tiposdocumentos` */

DROP TABLE IF EXISTS `tiposdocumentos`;

CREATE TABLE `tiposdocumentos` (
  `tipoDocId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipoDocCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoDocTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoDocActual` int(11) NOT NULL DEFAULT '0',
  `tipoDocLongitud` int(10) NOT NULL DEFAULT '6',
  `tipoDocRelleno` varchar(2) COLLATE utf8_spanish2_ci NOT NULL DEFAULT '0',
  `tipoDocAlerta` int(11) NOT NULL DEFAULT '999',
  `tipoDocPlantilla` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  PRIMARY KEY (`tipoDocId`),
  UNIQUE KEY `UQ_TipoDocumento_tipoDocId` (`tipoDocId`),
  UNIQUE KEY `UQ_TipoDocumento_tipoDocCodigo` (`tipoDocCodigo`),
  UNIQUE KEY `UQ_TipoDocumento_tipoDocTitulo` (`tipoDocTitulo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `tiposdocumentos` */

/*!40000 ALTER TABLE `tiposdocumentos` DISABLE KEYS */;

insert  into `tiposdocumentos`(`tipoDocId`,`tipoDocCodigo`,`tipoDocTitulo`,`tipoDocActual`,`tipoDocLongitud`,`tipoDocRelleno`,`tipoDocAlerta`,`tipoDocPlantilla`) values (1,'RECIBOEQUIPOS','Recibo de Servicio de Equipos',0,6,'0',999,NULL);
insert  into `tiposdocumentos`(`tipoDocId`,`tipoDocCodigo`,`tipoDocTitulo`,`tipoDocActual`,`tipoDocLongitud`,`tipoDocRelleno`,`tipoDocAlerta`,`tipoDocPlantilla`) values (2,'RECIBODEPOSITOS','Comprobante de Deposito',0,6,'0',999,NULL);
insert  into `tiposdocumentos`(`tipoDocId`,`tipoDocCodigo`,`tipoDocTitulo`,`tipoDocActual`,`tipoDocLongitud`,`tipoDocRelleno`,`tipoDocAlerta`,`tipoDocPlantilla`) values (3,'DEVOLUCIONDEPOSITO','Devolución de Deposito',0,6,'0',999,NULL);

/*!40000 ALTER TABLE  `tiposdocumentos` ENABLE KEYS */;

/*Table structure for table `tiposequipos` */

DROP TABLE IF EXISTS `tiposequipos`;

CREATE TABLE `tiposequipos` (
  `tipoEquipoId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipoEquipoCodigo` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoEquipoTitulo` varbinary(255) NOT NULL,
  `tipoEquipoDesc` text COLLATE utf8_spanish2_ci,
  `tipoEquipoEstado` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  `tipoEquipoFecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`tipoEquipoId`),
  UNIQUE KEY `UQ_TiposEquipos_tipoEquipoId` (`tipoEquipoId`),
  UNIQUE KEY `UQ_TiposEquipos_tipoEquipoCodigo` (`tipoEquipoCodigo`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `tiposequipos` */

/*!40000 ALTER TABLE `tiposequipos` DISABLE KEYS */;

insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (1,'OXIGENOIND','CILINDROS OXIGENO INDUSTRIAL','','ACTIVO','2016-01-20 11:24:12');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (2,'REGMEDICIN','REGULADORES MEDICINALES','','ACTIVO','2016-01-20 11:24:41');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (3,'CONCENTRAD','CONCENTRADORES','','ACTIVO','2016-01-21 07:50:18');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (4,'SUCCIONADO','SUCCIONADORES','','ACTIVO','2016-01-21 07:50:34');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (5,'REGINDUSTR','REGULADORES INDUSTRIALES','','ACTIVO','2016-01-22 09:48:33');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (6,'CILPORTATI','CILINDRO PORTATIL MEDICINAL','','ACTIVO','2016-01-22 13:35:09');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (7,'CARRITO','CARRITO PORTATIL','','ACTIVO','2016-01-22 13:57:51');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (8,'ARGON','CILINDRO ARGON INDUSTRIAL','','ACTIVO','2016-01-28 09:28:34');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (9,'NITROGENO','CILINDRO NITROGENO INDUSTRIAL','','ACTIVO','2016-01-28 09:29:10');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (10,'OXIGENOMED','CILINDROS DE OXIGENO MEDICINAL','','ACTIVO','2016-01-28 10:18:11');
insert  into `tiposequipos`(`tipoEquipoId`,`tipoEquipoCodigo`,`tipoEquipoTitulo`,`tipoEquipoDesc`,`tipoEquipoEstado`,`tipoEquipoFecha`) values (11,'MIX','CILINDRO DE MIX INDUSTRIAL','','ACTIVO','2016-01-28 10:27:21');

/*!40000 ALTER TABLE  `tiposequipos` ENABLE KEYS */;

/*Table structure for table `tiposidentificacion` */

DROP TABLE IF EXISTS `tiposidentificacion`;

CREATE TABLE `tiposidentificacion` (
  `tipoIdentificacionId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipoIdentificacionCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoIdentificacionTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoIdentificacionEstado` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  PRIMARY KEY (`tipoIdentificacionId`),
  UNIQUE KEY `UQ_TipoIdentificacion_tipoIdentificacionId` (`tipoIdentificacionId`),
  UNIQUE KEY `UQ_TipoIdentificacion_tipoIdentificacionCodigo` (`tipoIdentificacionCodigo`),
  UNIQUE KEY `UQ_TipoIdentificacion_tipoIdentificacionTItulo` (`tipoIdentificacionTitulo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `tiposidentificacion` */

/*!40000 ALTER TABLE `tiposidentificacion` DISABLE KEYS */;

insert  into `tiposidentificacion`(`tipoIdentificacionId`,`tipoIdentificacionCodigo`,`tipoIdentificacionTitulo`,`tipoIdentificacionEstado`) values (1,'CC','Cedula de Ciudadania','ACTIVO');
insert  into `tiposidentificacion`(`tipoIdentificacionId`,`tipoIdentificacionCodigo`,`tipoIdentificacionTitulo`,`tipoIdentificacionEstado`) values (2,'NIT','Numero de Identificacion Tributaria','ACTIVO');

/*!40000 ALTER TABLE  `tiposidentificacion` ENABLE KEYS */;

/*Table structure for table `tiposmotivos` */

DROP TABLE IF EXISTS `tiposmotivos`;

CREATE TABLE `tiposmotivos` (
  `tipoMotivoId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipoMotivoCodigo` varchar(10) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoMotivoTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoMotivoDescripcion` text COLLATE utf8_spanish2_ci,
  PRIMARY KEY (`tipoMotivoId`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `tiposmotivos` */

/*!40000 ALTER TABLE `tiposmotivos` DISABLE KEYS */;

insert  into `tiposmotivos`(`tipoMotivoId`,`tipoMotivoCodigo`,`tipoMotivoTitulo`,`tipoMotivoDescripcion`) values (1,'ANULACION','Anular Servicio','Se anula el servicio y el documento o recibo del mismo. ');
insert  into `tiposmotivos`(`tipoMotivoId`,`tipoMotivoCodigo`,`tipoMotivoTitulo`,`tipoMotivoDescripcion`) values (2,'REGENERACI','Generar Nuevo Servicio','Se generará un nuevo servicio y un nuevo documento de soporte con una nueva numeración y con la fecha de hoy. ');
insert  into `tiposmotivos`(`tipoMotivoId`,`tipoMotivoCodigo`,`tipoMotivoTitulo`,`tipoMotivoDescripcion`) values (3,'NUEVODOCUM','Generar Nuevo Documento','Se generará solo el documento o recibo del servicio nuevamente, con su nueva numeración. ');
insert  into `tiposmotivos`(`tipoMotivoId`,`tipoMotivoCodigo`,`tipoMotivoTitulo`,`tipoMotivoDescripcion`) values (4,'DEVOLUCION','Devolucion del Servicio','Igual que el anular, solo que este se diferencia porque el servicio fue devuelto.');
insert  into `tiposmotivos`(`tipoMotivoId`,`tipoMotivoCodigo`,`tipoMotivoTitulo`,`tipoMotivoDescripcion`) values (5,'CAMBIODEPO','Cambio en el Deposito','Se cambiarón las condiciones del deposito para el servicio.');
insert  into `tiposmotivos`(`tipoMotivoId`,`tipoMotivoCodigo`,`tipoMotivoTitulo`,`tipoMotivoDescripcion`) values (6,'CAMBIODIRE','Cambio de la Direccion del Servicio','Se cambió la direccion o ubicación del servicio.');
insert  into `tiposmotivos`(`tipoMotivoId`,`tipoMotivoCodigo`,`tipoMotivoTitulo`,`tipoMotivoDescripcion`) values (7,'CAMBIOCLIE','Cambio del Cliente del Servicio','Se cambio el CLIENTE asociado al servicio.');
insert  into `tiposmotivos`(`tipoMotivoId`,`tipoMotivoCodigo`,`tipoMotivoTitulo`,`tipoMotivoDescripcion`) values (8,'CAMBIOREFE','Cambio de la Referencia del Cliente','Se cambió la referencia del cliente para el servicio.');

/*!40000 ALTER TABLE  `tiposmotivos` ENABLE KEYS */;

/*Table structure for table `tiposmovimientos` */

DROP TABLE IF EXISTS `tiposmovimientos`;

CREATE TABLE `tiposmovimientos` (
  `movimientoId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `movimientoCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `movimientoTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `movimientoTitulo2` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`movimientoId`),
  UNIQUE KEY `UQ_TiposMoviminetos_movimientoId` (`movimientoId`),
  UNIQUE KEY `UQ_TiposMoviminetos_movimientoCodigo` (`movimientoCodigo`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `tiposmovimientos` */

/*!40000 ALTER TABLE `tiposmovimientos` DISABLE KEYS */;

insert  into `tiposmovimientos`(`movimientoId`,`movimientoCodigo`,`movimientoTitulo`,`movimientoTitulo2`) values (1,'ENSERVICIO','EN SERVICIO O ENTREGRADO AL CLIENTE','RECIBIDO');
insert  into `tiposmovimientos`(`movimientoId`,`movimientoCodigo`,`movimientoTitulo`,`movimientoTitulo2`) values (2,'RECOGIDO','EL CLIENTE ENTREGÓ EL EQUIPO','ENTREGADO');
insert  into `tiposmovimientos`(`movimientoId`,`movimientoCodigo`,`movimientoTitulo`,`movimientoTitulo2`) values (3,'PERDIDA','NO SE CONOCE EL DESTINO DEL EQUIPO','NO ENTREGADO');
insert  into `tiposmovimientos`(`movimientoId`,`movimientoCodigo`,`movimientoTitulo`,`movimientoTitulo2`) values (4,'NOFUNCIONO','MAL FUNCIONAMIENTO','DEVUELTO');

/*!40000 ALTER TABLE  `tiposmovimientos` ENABLE KEYS */;

/*Table structure for table `tipospersonas` */

DROP TABLE IF EXISTS `tipospersonas`;

CREATE TABLE `tipospersonas` (
  `tipoPersonaId` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tipoPersonaCodigo` varchar(50) COLLATE utf8_spanish2_ci NOT NULL,
  `tipoPersonaTitulo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  PRIMARY KEY (`tipoPersonaId`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `tipospersonas` */

/*!40000 ALTER TABLE `tipospersonas` DISABLE KEYS */;

insert  into `tipospersonas`(`tipoPersonaId`,`tipoPersonaCodigo`,`tipoPersonaTitulo`) values (1,'EMPLEADOS','Empleados / Usuario');
insert  into `tipospersonas`(`tipoPersonaId`,`tipoPersonaCodigo`,`tipoPersonaTitulo`) values (2,'CLIENTE','Cliente');
insert  into `tipospersonas`(`tipoPersonaId`,`tipoPersonaCodigo`,`tipoPersonaTitulo`) values (3,'PROVEEDOR','Proveedor');

/*!40000 ALTER TABLE  `tipospersonas` ENABLE KEYS */;

/*Table structure for table `usuarios` */

DROP TABLE IF EXISTS `usuarios`;

CREATE TABLE `usuarios` (
  `usuarioId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuarioPersona` bigint(20) NOT NULL,
  `usuarioCargo` int(10) NOT NULL,
  `usuarioTipo` enum('REPARTIDOR','SUPERVISOR','ADMINISTRADOR','SUPER') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'REPARTIDOR',
  `usuarioNombre` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `usuarioClave` text COLLATE utf8_spanish2_ci,
  `usuarioCorreo` varchar(255) COLLATE utf8_spanish2_ci NOT NULL,
  `usuarioTelefono` varchar(50) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `usuarioUltimoIngreso` timestamp NULL DEFAULT NULL,
  `usuarioUltimaIp` varchar(255) COLLATE utf8_spanish2_ci DEFAULT NULL,
  `usuarioUltimaUbicacionLatitud` varchar(50) COLLATE utf8_spanish2_ci DEFAULT '11.227442290719976',
  `usuarioUltimaUbicacionLongitud` varchar(50) COLLATE utf8_spanish2_ci DEFAULT '-74.196954430081',
  `usuarioCreado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuarioCreo` bigint(20) DEFAULT NULL,
  `usuarioEstado` enum('ACTIVO','DESACTIVO') COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'ACTIVO',
  `usuarioAvatar` varchar(255) COLLATE utf8_spanish2_ci NOT NULL DEFAULT 'archivos/oximeiser/avatares/default.png',
  PRIMARY KEY (`usuarioId`),
  UNIQUE KEY `UQ_Usuarios_usuarioId` (`usuarioId`),
  KEY `IXFK_Usuarios_CargosEmpleados` (`usuarioCargo`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `usuarios` */

/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;

insert  into `usuarios`(`usuarioId`,`usuarioPersona`,`usuarioCargo`,`usuarioTipo`,`usuarioNombre`,`usuarioClave`,`usuarioCorreo`,`usuarioTelefono`,`usuarioUltimoIngreso`,`usuarioUltimaIp`,`usuarioUltimaUbicacionLatitud`,`usuarioUltimaUbicacionLongitud`,`usuarioCreado`,`usuarioCreo`,`usuarioEstado`,`usuarioAvatar`) values (0,1,1,'SUPER','palmasoft','a95c5a1e7a1da568c5f08d7f1f51b622','',NULL,'2016-01-28 19:11:11','186.1.175.12','11.2286539','-74.19803859999999','2015-09-29 00:33:22',NULL,'ACTIVO','archivos/oximeiser/avatares/administrador.png');
insert  into `usuarios`(`usuarioId`,`usuarioPersona`,`usuarioCargo`,`usuarioTipo`,`usuarioNombre`,`usuarioClave`,`usuarioCorreo`,`usuarioTelefono`,`usuarioUltimoIngreso`,`usuarioUltimaIp`,`usuarioUltimaUbicacionLatitud`,`usuarioUltimaUbicacionLongitud`,`usuarioCreado`,`usuarioCreo`,`usuarioEstado`,`usuarioAvatar`) values (1,2,2,'ADMINISTRADOR','DVIDAL','25f9e794323b453885f5181f1b624d0b','dvidal@oximeiser.com','300-7770191','2016-01-28 09:23:54','186.114.158.44','11.2276454','-74.1971502','2016-01-18 08:33:11',0,'ACTIVO','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-123456789-569cf7a794113.jpg');
insert  into `usuarios`(`usuarioId`,`usuarioPersona`,`usuarioCargo`,`usuarioTipo`,`usuarioNombre`,`usuarioClave`,`usuarioCorreo`,`usuarioTelefono`,`usuarioUltimoIngreso`,`usuarioUltimaIp`,`usuarioUltimaUbicacionLatitud`,`usuarioUltimaUbicacionLongitud`,`usuarioCreado`,`usuarioCreo`,`usuarioEstado`,`usuarioAvatar`) values (14,3,3,'REPARTIDOR','WOLMOS','e10adc3949ba59abbe56e057f20f883e','DVIDAL@OXIMEISER.COM','301-204690',NULL,NULL,'11.227442290719976','-74.196954430081','2016-01-18 11:31:49',1,'ACTIVO','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-12555717-569d21852b71d.jpg');
insert  into `usuarios`(`usuarioId`,`usuarioPersona`,`usuarioCargo`,`usuarioTipo`,`usuarioNombre`,`usuarioClave`,`usuarioCorreo`,`usuarioTelefono`,`usuarioUltimoIngreso`,`usuarioUltimaIp`,`usuarioUltimaUbicacionLatitud`,`usuarioUltimaUbicacionLongitud`,`usuarioCreado`,`usuarioCreo`,`usuarioEstado`,`usuarioAvatar`) values (15,4,6,'SUPERVISOR','BJIMENEZ','e10adc3949ba59abbe56e057f20f883e','HUGOVIDALCASTRO@YAHOO.COM.CO','300-7766774',NULL,NULL,'11.227442290719976','-74.196954430081','2016-01-19 10:21:03',1,'ACTIVO','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-57433944-569e626fe83dc.jpg');
insert  into `usuarios`(`usuarioId`,`usuarioPersona`,`usuarioCargo`,`usuarioTipo`,`usuarioNombre`,`usuarioClave`,`usuarioCorreo`,`usuarioTelefono`,`usuarioUltimoIngreso`,`usuarioUltimaIp`,`usuarioUltimaUbicacionLatitud`,`usuarioUltimaUbicacionLongitud`,`usuarioCreado`,`usuarioCreo`,`usuarioEstado`,`usuarioAvatar`) values (16,5,7,'REPARTIDOR','MHERNANDEZ','4e544600f06f686fba27c922729b69aa','MHERNANDEZ@OXIMEISER.COM','300-4978857',NULL,NULL,'11.227442290719976','-74.196954430081','2016-01-19 11:01:56',1,'ACTIVO','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-1082905679-569e6c046e545.jpg');
insert  into `usuarios`(`usuarioId`,`usuarioPersona`,`usuarioCargo`,`usuarioTipo`,`usuarioNombre`,`usuarioClave`,`usuarioCorreo`,`usuarioTelefono`,`usuarioUltimoIngreso`,`usuarioUltimaIp`,`usuarioUltimaUbicacionLatitud`,`usuarioUltimaUbicacionLongitud`,`usuarioCreado`,`usuarioCreo`,`usuarioEstado`,`usuarioAvatar`) values (17,6,5,'SUPERVISOR','CMUÑOZ','4e544600f06f686fba27c922729b69aa','CMUNOZ@OXIMEISER.COM','',NULL,NULL,'11.227442290719976','-74.196954430081','2016-01-19 11:06:16',1,'ACTIVO','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-39143542-569e6d089e2ab.jpg');
insert  into `usuarios`(`usuarioId`,`usuarioPersona`,`usuarioCargo`,`usuarioTipo`,`usuarioNombre`,`usuarioClave`,`usuarioCorreo`,`usuarioTelefono`,`usuarioUltimoIngreso`,`usuarioUltimaIp`,`usuarioUltimaUbicacionLatitud`,`usuarioUltimaUbicacionLongitud`,`usuarioCreado`,`usuarioCreo`,`usuarioEstado`,`usuarioAvatar`) values (18,7,9,'SUPERVISOR','HVIDAL','4e544600f06f686fba27c922729b69aa','HUGOVIDALCASTRO@YAHOO.COM.CO','316-2455225',NULL,NULL,'11.227442290719976','-74.196954430081','2016-01-19 11:08:47',1,'ACTIVO','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-16856763-569e6d9f53c96.jpg');
insert  into `usuarios`(`usuarioId`,`usuarioPersona`,`usuarioCargo`,`usuarioTipo`,`usuarioNombre`,`usuarioClave`,`usuarioCorreo`,`usuarioTelefono`,`usuarioUltimoIngreso`,`usuarioUltimaIp`,`usuarioUltimaUbicacionLatitud`,`usuarioUltimaUbicacionLongitud`,`usuarioCreado`,`usuarioCreo`,`usuarioEstado`,`usuarioAvatar`) values (19,8,10,'SUPERVISOR','MACOSTA','4e544600f06f686fba27c922729b69aa','DVIDAL@OXIMEISER.COM','308-463414',NULL,NULL,'11.227442290719976','-74.196954430081','2016-01-19 11:12:24',1,'ACTIVO','http://siom.oximeiser.com/archivos/oximeiser/personas/empleados/logo-1-36693762-569e6e78a4af1.jpg');

/*!40000 ALTER TABLE  `usuarios` ENABLE KEYS */;

/*Table structure for table `usuariosfunciones` */

DROP TABLE IF EXISTS `usuariosfunciones`;

CREATE TABLE `usuariosfunciones` (
  `usuarioFuncionId` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `usuarioFuncion` bigint(20) NOT NULL COMMENT 'EL usuario al que se le asigna la funcion usuarioFuncionAsignada',
  `usuarioFuncionAsignada` int(10) NOT NULL COMMENT 'funcion que se le asigna a usuarioFuncion',
  `usuarioFuncionAsignado` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `usuarioFuncionAsigna` bigint(20) NOT NULL,
  PRIMARY KEY (`usuarioFuncionId`),
  UNIQUE KEY `UQ_UsuariosFunciones_usuarioFuncionId` (`usuarioFuncionId`),
  KEY `IXFK_UsuariosFunciones_Usuarios` (`usuarioFuncion`),
  KEY `IXFK_UsuariosFunciones_FuncionesSistema` (`usuarioFuncionAsignada`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish2_ci;

/*Data for the table `usuariosfunciones` */

/*!40000 ALTER TABLE `usuariosfunciones` DISABLE KEYS */;

insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (15,14,11,'2016-01-18 11:31:49',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (16,14,19,'2016-01-18 11:31:49',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (17,14,13,'2016-01-18 11:31:49',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (33,15,9,'2016-01-19 10:21:04',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (34,15,17,'2016-01-19 10:21:04',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (35,15,14,'2016-01-19 10:21:04',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (36,15,16,'2016-01-19 10:21:04',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (37,15,11,'2016-01-19 10:21:04',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (38,15,19,'2016-01-19 10:21:04',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (39,15,13,'2016-01-19 10:21:04',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (63,1,9,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (64,1,17,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (65,1,6,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (66,1,14,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (67,1,16,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (68,1,4,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (69,1,8,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (70,1,3,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (71,1,7,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (72,1,11,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (73,1,19,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (74,1,20,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (75,1,13,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (76,1,2,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (77,1,5,'2016-01-19 11:23:54',0);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (78,17,9,'2016-01-21 07:48:03',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (79,17,17,'2016-01-21 07:48:03',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (80,17,14,'2016-01-21 07:48:03',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (81,17,13,'2016-01-21 07:48:03',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (82,18,9,'2016-01-21 07:48:24',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (83,18,17,'2016-01-21 07:48:24',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (84,18,14,'2016-01-21 07:48:24',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (85,18,16,'2016-01-21 07:48:24',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (86,18,7,'2016-01-21 07:48:24',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (87,18,11,'2016-01-21 07:48:24',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (88,18,19,'2016-01-21 07:48:24',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (89,18,13,'2016-01-21 07:48:24',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (90,19,14,'2016-01-21 07:48:58',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (91,19,8,'2016-01-21 07:48:58',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (92,16,9,'2016-01-21 07:49:23',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (93,16,17,'2016-01-21 07:49:23',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (94,16,14,'2016-01-21 07:49:23',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (95,16,16,'2016-01-21 07:49:23',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (96,16,11,'2016-01-21 07:49:23',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (97,16,19,'2016-01-21 07:49:23',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (98,16,20,'2016-01-21 07:49:23',1);
insert  into `usuariosfunciones`(`usuarioFuncionId`,`usuarioFuncion`,`usuarioFuncionAsignada`,`usuarioFuncionAsignado`,`usuarioFuncionAsigna`) values (99,16,13,'2016-01-21 07:49:23',1);

/*!40000 ALTER TABLE  `usuariosfunciones` ENABLE KEYS */;

/* Function  structure for function  `usarConsecutivoDocumento` */

/*!50003 DROP FUNCTION IF EXISTS `usarConsecutivoDocumento` */;
DELIMITER $$

/*!50003 CREATE DEFINER=`oximeiser`@`190.90.87.66` FUNCTION `usarConsecutivoDocumento`(COD_DOC VARCHAR (50)) RETURNS varchar(50) CHARSET utf8 COLLATE utf8_spanish2_ci
BEGIN
  DECLARE CONSECUTIVO VARCHAR (50) ;
  UPDATE 
    `tiposdocumentos` 
  SET
    `tipoDocActual` = tipoDocActual + 1 
  WHERE `tipoDocCodigo` = COD_DOC ;
  SELECT 
    LPAD(
      tiposdocumentos.tipoDocActual
      , tiposdocumentos.tipoDocLongitud
      , tiposdocumentos.tipoDocRelleno
    ) INTO CONSECUTIVO 
  FROM
    tiposdocumentos 
  WHERE `tipoDocCodigo` = COD_DOC ;
  RETURN CONSECUTIVO ;
END */$$
DELIMITER ;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
